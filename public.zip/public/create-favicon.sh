#!/bin/bash
# Script para criar favicon.ico a partir do SVG
# Requer ImageMagick: brew install imagemagick
if command -v convert &> /dev/null; then
  convert -background none -resize 32x32 public/favicon.svg public/favicon.ico
  echo "✅ favicon.ico criado!"
else
  echo "⚠️  ImageMagick não instalado. Use um gerador online: https://favicon.io/"
fi
